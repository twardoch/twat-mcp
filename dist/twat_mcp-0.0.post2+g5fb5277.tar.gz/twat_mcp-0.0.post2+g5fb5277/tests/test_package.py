"""Test suite for twat_mcp."""

def test_version():
    """Verify package exposes version."""
    import twat_mcp
    assert twat_mcp.__version__
